create definer = root@localhost trigger enforce_admin_credentials
    before insert
    on Users
    for each row
BEGIN
    IF NEW.username = 'admin' THEN
        SET NEW.password = 'admin@123';
        SET NEW.role = 'admin';
        SET NEW.email = NULL; -- Ensure email is NULL for admin
    END IF;
END;

